<title>Check Username</title>
<center>
<br>
<table width=90% bgcolor="white">
<tr>
  <td class=font10_black align=center>
  <b>Login Error..!</b><br><br>
  <?php 
  if ($id=="status")  echo "Username belum diizinkan untuk mengakses fasilitas member";
  else  echo "Salah Username atau Password";
  ?><br><br>
  </td>
</tr>
</table>
</center>
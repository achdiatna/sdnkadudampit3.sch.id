      <?php
switch($id) {
	case 1 : echo "<center><h3>Database belum ada</h3><center>";
			 break;
	case 2 : echo "Nama diisi";
			 break;
	case 3 : echo "Password diisi";
			 break;
	case 4 : echo "User name tidak diketahui";
			 break;
	default : echo "Periksa kembali";
	}
?>

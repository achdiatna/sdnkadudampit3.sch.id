//-------------------------------------------------------------
//	Created by: Ionel Alexandru 
//	Mail: ionel.alexandru@gmail.com
//	Site: www.fmath.info
//---------------------------------------------------------------

tinyMCE.addI18n('en.fmath_formula',{
	desc : 'Add MathML Formula'
});

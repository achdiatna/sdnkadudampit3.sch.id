<?php
$tag .="<center><form id='form1' name='login' action='../member/index.php' method='post'>
<table border='0' width='100%'  ><tr><td >Username</td><td>:<input type='text' name='username' class='editbox' size='17' title='Masukan Username'></td></tr>
<tr><td>Password </td><td>:<input type='password' name='password' class='editbox' size='17' title='Masukan Password'></td></tr>
<tr><td colspan=2 ><input type='submit' value='  Login  ' class='art-button' >
<input type='hidden' name='lang' value='id'><input type='submit' value=' Daftar ' class='art-button' onclick='daftar()'  ></td></tr></table></form></center>";
?>
<?php
$tag .="<a HREF=\"http://www.myQuran.com\" target=\"_blank\" style=\"padding-left: 27px\">
<IMG SRC=\"http://myquran.com/sholat/?type=png&kota=6222\" alt=\"Jadwal Sholat Kota Bandung\" />
</a>";
?>
<?php
$tag .="<form action='index.php' method='post' ><table><tr><td><input type='text' name='query' size='17' /></td><td>
<input type='submit' value='Cari' class='art-button'  /></td></tr><input type='hidden' value='cari' name='id'  /></table></form>";

?>